#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "Propagator.h"
#include "Polarization.h"

int main(int argc, char *argv[])
{
	//Seed rand()
	srand(time(NULL));
	int count = 0;
	std::pair<float,float> ice_d(1000.0,-2000.0);
	std::pair<float,float> emitter_p(0.0,-800.0);
	std::pair<bool,bool> preferences(true,true);//Change first argument to true if smooth model needed, false gives non-smooth model
	std::vector<float> pol(3);
	pol[0] = 0.0;
	pol[1] = 0.0;
	pol[2] = 1.0;
	float globalTime = 20000.0; //Increase globalTime to propagate for longer time
	char mode;

	std::cout<<"Select which which type of model you want ('r' for pure relfection, 't' for transmission, and 'h' for horizontal propagation): ";
	std::cin>>mode;
	
	Propagator p;
	for (float z=-150.0;z<=0.0;z+=5.0) //Using only one reflecting layer at surface to look similar to octave code
	  {
	    float r = float(rand())/float(RAND_MAX)/10.0;
	p.AddReflector(std::pair<float,float>(z,r),std::pair<int,float>(1,0.1));
	std::cout <<"Added reflecting layer at "<<z<<" meters with R= " <<r<<std::endl;
	  }
	for(float t=19.0;t<=19.0;t+=1.0)
	{
		std::cout<<"Angle: "<<t<<std::endl;
		
		
		p.InitializePropagator(globalTime,ice_d,preferences,"SPICE",emitter_p,t,pol,mode);
			if (mode =='r'||mode=='t')
			  {
			p.Propagate();
			std::stringstream ss;
			ss<<count;
			std::string title = "data/propagation_path_"+ss.str()+".dat";
			p.ReadoutPath(title);
			++count;
			  }

			/*	else if (mode == 'h')
			  {
			    
			p.Propagate();
			std::stringstream ss;
			ss<<count;
			std::string title = "data/propagation_path_"+ss.str()+".dat";
			  }*/
			
		
		
	}
}
